//
//  Vungle.h
//  AdsHelper
//
//  Created by Xufei Wu on 2017/6/24.
//  Copyright © 2017年 Xufei Wu. All rights reserved.
//

#ifndef Vungle_h
#define Vungle_h

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface VungleHelper : NSObject

    + (VungleHelper*) GetDelegate;
    - (void) InitSDK:(NSString*) AppID callback:(void(*)()) callback;
    -(void) Play:(UIViewController*) viewController;
    -(void) IsPlayable:(NSMutableDictionary*)result;
@end


#endif /* Header_h */
